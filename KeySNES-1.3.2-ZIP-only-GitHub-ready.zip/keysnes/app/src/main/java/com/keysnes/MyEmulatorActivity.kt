package com.keysnes.emulator

import android.annotation.SuppressLint
import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.View.OnTouchListener
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import nostalgia.appnes.NesEmulator
import nostalgia.framework.base.EmulatorActivity
import nostalgia.framework.base.Manager
import nostalgia.framework.base.OpenGLView
import nostalgia.framework.ui.gamegallery.GameDescription
import java.io.File

class MyEmulatorActivity : EmulatorActivity(), OnTouchListener {
    private lateinit var emulator: nostalgia.framework.Emulator
    private lateinit var manager: Manager
    private var game: GameDescription? = null
    private val keyMap = HashMap<Int, Int>()

    private val shader1 = "precision mediump float; varying vec2 v_texCoord; uniform sampler2D s_texture; void main(){ gl_FragColor=texture2D(s_texture,v_texCoord); }"

    override fun useCustomLifecycle(): Boolean = true

    override fun getEmulatorInstance(): nostalgia.framework.Emulator = NesEmulator.getInstance()
    override fun getFragmentShader(): String = shader1
    override fun getGLTextureSize(): Int = 256
    override fun hasGLPalette(): Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(null)
        emulator = getEmulatorInstance()
        manager = Manager(emulator, applicationContext)

        val romPath = intent.getStringExtra(EXTRA_ROM_PATH)
        if (romPath.isNullOrBlank()) {
            Toast.makeText(this, "ROM de SNES não encontrada", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        game = GameDescription(File(romPath))
        val romName = intent.getStringExtra(EXTRA_ROM_NAME) ?: File(romPath).nameWithoutExtension
        val romId = intent.getStringExtra(EXTRA_ROM_ID) ?: romPath
        GameLibrary.setRecent(this, GameLibrary.Game(romId, romName, romPath))

        setContentView(R.layout.activity_nes_emulator)
        val container = findViewById<ViewGroup>(R.id.emulatorContainer)
        val gl = OpenGLView(this, emulator, 0, 0, shader1)
        // High-quality timing in the legacy framework uses a 17 ms frame cadence.
        // Avoid the default 40 ms pacing because it adds visible input/display latency.
        gl.setQuality(2)
        container.addView(gl, ViewGroup.LayoutParams(-1, -1))

        bindKeys()
        initGameMenu()
        applyOrientationLayout(resources.configuration.orientation)

        manager.startGame(game!!)
        if (intent.getBooleanExtra(EXTRA_RESUME_AUTO_STATE, false)) {
            // Resume only the framework's automatic slot (0).
            // User save states (slots 1..8) remain completely untouched.
            manager.loadState(0)
        }
        val prefs = getSharedPreferences(SettingsActivity.PREFS_NAME, MODE_PRIVATE)
        if (prefs.getBoolean("jardel", false)) {
            manager.setFastForwardFrameCount(1) // 1 skipped + 1 rendered frame ~= 2x
            manager.setFastForwardEnabled(true)
        }
        applyFullscreen(prefs.getBoolean("fullscreen", false))
        applyKeepScreenOn(prefs.getBoolean("keep_screen_on", false))
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyOrientationLayout(newConfig.orientation)
    }

    private fun bindKeys() {
        map(R.id.keyB, 1)
        map(R.id.keyY, 2)
        map(R.id.keySelect, 4)
        map(R.id.keyStart, 8)
        map(R.id.keyUp, 16)
        map(R.id.keyDown, 32)
        map(R.id.keyLeft, 64)
        map(R.id.keyRight, 128)
        map(R.id.keyA, 256)
        map(R.id.keyX, 512)
        mapExtra(R.id.keyL, 10)
        mapExtra(R.id.keyR, 11)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun map(id: Int, key: Int) {
        findViewById<TextView>(id)?.let {
            keyMap[id] = key
            it.setOnTouchListener(this)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun mapExtra(id: Int, button: Int) {
        findViewById<TextView>(id)?.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> CoreBridge.extra(button, true)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> CoreBridge.extra(button, false)
            }
            true
        }
    }

    private object CoreBridge {
        private val core = nostalgia.appnes.Core.getInstance()
        fun extra(button: Int, pressed: Boolean) = core.setExtraButton(button, pressed)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouch(v: View?, event: MotionEvent?): Boolean {
        val key = keyMap[v?.id] ?: return false
        when (event?.actionMasked) {
            MotionEvent.ACTION_DOWN -> emulator.setKeyPressed(0, key, true)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> emulator.setKeyPressed(0, key, false)
        }
        return true
    }

    private fun initGameMenu() {
        findViewById<View>(R.id.btnGameSettings)?.setOnClickListener { showSettingsMenu() }
        findViewById<View>(R.id.btnGameController)?.setOnClickListener { showControllerMenu() }
        findViewById<View>(R.id.btnGameMore)?.setOnClickListener { showMoreMenu(it) }
        findViewById<View>(R.id.btnGameRoms)?.setOnClickListener { finish() }
    }


    private fun showMoreMenu(anchor: View) {
        val romPath = intent.getStringExtra(EXTRA_ROM_PATH) ?: return
        val romName = intent.getStringExtra(EXTRA_ROM_NAME) ?: File(romPath).nameWithoutExtension
        val romId = intent.getStringExtra(EXTRA_ROM_ID) ?: romPath
        val game = GameLibrary.Game(romId, romName, romPath)
        val popup = PopupMenu(this, anchor)
        val favoriteItem = popup.menu.add(if (GameLibrary.isFavorite(this, game.id)) "Remover dos favoritos" else "Favoritar jogo")
        favoriteItem.setIcon(R.drawable.ic_star)
        popup.setOnMenuItemClickListener {
            val added = GameLibrary.toggleFavorite(this, game)
            Toast.makeText(this, if (added) "Jogo adicionado aos favoritos" else "Jogo removido dos favoritos", Toast.LENGTH_SHORT).show()
            true
        }
        popup.show()
    }

    private fun showSettingsMenu() {
        AlertDialog.Builder(this)
            .setTitle("KeySNES")
            .setItems(arrayOf("Salvar estado", "Carregar estado", "Saída")) { dialog, which ->
                try {
                    when (which) {
                        0 -> { manager.saveState(1); Toast.makeText(this, "Estado salvo", Toast.LENGTH_SHORT).show() }
                        1 -> { manager.loadState(1); Toast.makeText(this, "Estado carregado", Toast.LENGTH_SHORT).show() }
                        2 -> finish()
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "Não foi possível acessar o estado", Toast.LENGTH_SHORT).show()
                }
                dialog.dismiss()
            }.show()
    }

    private fun showControllerMenu() {
        val prefs = getSharedPreferences(SettingsActivity.PREFS_NAME, MODE_PRIVATE)
        val labels = arrayOf("Tela toda preenchida", "Modo Jardel")
        val checked = booleanArrayOf(prefs.getBoolean("fullscreen", false), prefs.getBoolean("jardel", false))
        AlertDialog.Builder(this).setTitle("Controle e tela")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked ->
                when (which) {
                    0 -> { prefs.edit().putBoolean("fullscreen", isChecked).apply(); applyFullscreen(isChecked) }
                    1 -> {
                        prefs.edit().putBoolean("jardel", isChecked).apply()
                        manager.setFastForwardFrameCount(1)
                        manager.setFastForwardEnabled(isChecked)
                    }
                }
            }.setPositiveButton("Fechar", null).show()
    }

    private fun applyKeepScreenOn(enabled: Boolean) {
        if (enabled) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun applyFullscreen(enabled: Boolean) {
        if (enabled) {
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        } else {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        }
    }

    private fun applyOrientationLayout(orientation: Int) {
        val landscape = orientation == Configuration.ORIENTATION_LANDSCAPE
        findViewById<View>(R.id.gameTopBar)?.let { bar ->
            bar.layoutParams.height = dp(if (landscape) 52 else 56)
            bar.setBackgroundColor(if (landscape) Color.TRANSPARENT else Color.argb(242, 13, 14, 16))
        }
        findViewById<View>(R.id.dpadArea)?.let { view ->
            val lp = view.layoutParams as? ViewGroup.MarginLayoutParams ?: return@let
            lp.width=dp(150); lp.height=dp(150); lp.leftMargin=dp(if (landscape) 24 else 18); lp.bottomMargin=dp(20); view.layoutParams=lp
        }
        listOf(R.id.keyA,R.id.keyB,R.id.keyX,R.id.keyY).forEach { id ->
            findViewById<View>(id)?.let { v ->
                val lp=v.layoutParams as? ViewGroup.MarginLayoutParams ?: return@let
                val size=dp(if (landscape) 66 else 64); lp.width=size; lp.height=size; v.layoutParams=lp
            }
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()

    @Deprecated("Deprecated on newer Android versions")
    override fun onBackPressed() {
        val prefs = getSharedPreferences(SettingsActivity.PREFS_NAME, MODE_PRIVATE)
        if (!prefs.getBoolean("confirm_exit", false)) {
            finish()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Sair do jogo?")
            .setMessage("O jogo será encerrado.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Sair") { _, _ -> finish() }
            .show()
    }

    override fun onPause() {
        if (::manager.isInitialized) manager.pauseEmulation()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (::manager.isInitialized) manager.resumeEmulation()
    }

    override fun onDestroy() {
        if (::manager.isInitialized) {
            try { manager.stopGame() } catch (_: Exception) { }
            try { manager.destroy() } catch (_: Exception) { }
        }
        super.onDestroy()
    }

    companion object {
        const val EXTRA_ROM_PATH = "keynes_rom_path"
        const val EXTRA_ROM_NAME = "keynes_rom_name"
        const val EXTRA_ROM_ID = "keynes_rom_id"
        const val EXTRA_RESUME_AUTO_STATE = "keynes_resume_auto_state"
    }
}
