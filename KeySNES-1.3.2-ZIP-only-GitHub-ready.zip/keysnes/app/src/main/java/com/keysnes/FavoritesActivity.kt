package com.keysnes.emulator

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File

class FavoritesActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_favorites)
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        renderFavorites()
    }

    private fun renderFavorites() {
        val container = findViewById<LinearLayout>(R.id.favoriteList)
        container.removeAllViews()
        val games = GameLibrary.getFavorites(this)
        findViewById<TextView>(R.id.favoriteSubtitle).text = when (games.size) {
            0 -> "Nenhum jogo favoritado."
            1 -> "1 jogo salvo como favorito."
            else -> "${games.size} jogos salvos como favoritos."
        }

        if (games.isEmpty()) {
            val empty = TextView(this).apply {
                text = "Abra uma ROM e use o menu ⋮ dentro do jogo para adicioná-la aos favoritos."
                setTextColor(Color.parseColor("#A9ADB5"))
                textSize = 15f
                setPadding(dp(4), dp(18), dp(4), dp(18))
            }
            container.addView(empty)
            return
        }

        games.forEach { game ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(18), dp(14), dp(14), dp(14))
                setBackgroundResource(R.drawable.keynes_card)
                isClickable = true
                isFocusable = true
            }
            val icon = ImageView(this).apply {
                setImageResource(R.drawable.ic_star)
                contentDescription = "Favorito"
            }
            row.addView(icon, LinearLayout.LayoutParams(dp(34), dp(34)))
            val text = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val title = TextView(this).apply {
                this.text = game.name
                setTextColor(Color.parseColor("#F1F2F4"))
                textSize = 17f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            }
            val path = TextView(this).apply {
                this.text = File(game.path).name
                setTextColor(Color.parseColor("#A9ADB5"))
                textSize = 13f
                setPadding(0, dp(3), 0, 0)
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            }
            text.addView(title)
            text.addView(path)
            row.addView(text, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(14) })
            row.setOnClickListener {
                if (!File(game.path).isFile) {
                    Toast.makeText(this, "A ROM não está mais disponível", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                startActivity(Intent(this, MyEmulatorActivity::class.java)
                    .putExtra(MyEmulatorActivity.EXTRA_ROM_PATH, game.path)
                    .putExtra(MyEmulatorActivity.EXTRA_ROM_NAME, game.name)
                    .putExtra(MyEmulatorActivity.EXTRA_ROM_ID, game.id)
                    .putExtra(MyEmulatorActivity.EXTRA_RESUME_AUTO_STATE, true))
            }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(82))
            lp.bottomMargin = dp(12)
            container.addView(row, lp)
        }
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density + 0.5f).toInt()
}
