package nostalgia.appnes;

import android.util.SparseIntArray;
import java.util.ArrayList;
import java.util.List;
import nostalgia.framework.BasicEmulatorInfo;
import nostalgia.framework.EmulatorController;
import nostalgia.framework.EmulatorInfo;
import nostalgia.framework.GfxProfile;
import nostalgia.framework.SfxProfile;
import nostalgia.framework.SfxProfile.SoundEncoding;
import nostalgia.framework.base.JniBridge;
import nostalgia.framework.base.JniEmulator;
import nostalgia.framework.ui.gamegallery.GameDescription;

/** SNES platform adapter backed by the official Snes9x core. */
public final class NesEmulator extends JniEmulator {
    public static final String PACK_SUFFIX = "sness";
    private static NesEmulator instance;
    private static EmulatorInfo info;
    private NesEmulator() {}
    public static JniEmulator getInstance() {
        if (instance == null) instance = new NesEmulator();
        return instance;
    }
    @Override public GfxProfile autoDetectGfx(GameDescription game) { return getInfo().getDefaultGfxProfile(); }
    @Override public SfxProfile autoDetectSfx(GameDescription game) { return getInfo().getDefaultSfxProfile(); }
    @Override public JniBridge getBridge() { return Core.getInstance(); }
    @Override public EmulatorInfo getInfo() { if (info == null) info = new Info(); return info; }

    private static final class Info extends BasicEmulatorInfo {
        private static final List<GfxProfile> GFX = new ArrayList<>();
        private static final List<SfxProfile> SFX = new ArrayList<>();
        static {
            GfxProfile ntsc = new SnesGfxProfile(); ntsc.fps=60; ntsc.name="NTSC"; ntsc.originalScreenWidth=256; ntsc.originalScreenHeight=224;
            GFX.add(ntsc);
            GfxProfile pal = new SnesGfxProfile(); pal.fps=50; pal.name="PAL"; pal.originalScreenWidth=256; pal.originalScreenHeight=224;
            GFX.add(pal);
            for (int q=0; q<3; q++) {
                SfxProfile s = new SnesSfxProfile(); s.name=q==0?"low":q==1?"medium":"high";
                s.bufferSize=32768; s.encoding=SoundEncoding.PCM16; s.isStereo=true; s.rate=32040; s.quality=q; SFX.add(s);
            }
        }
        @Override public SparseIntArray getKeyMapping() {
            SparseIntArray m = new SparseIntArray();
            m.put(EmulatorController.KEY_B, 1);  // bit 0
            m.put(EmulatorController.KEY_Y, 2);  // bit 1
            m.put(EmulatorController.KEY_SELECT, 4); // bit 2
            m.put(EmulatorController.KEY_START, 8);  // bit 3
            m.put(EmulatorController.KEY_UP, 16); m.put(EmulatorController.KEY_DOWN, 32);
            m.put(EmulatorController.KEY_LEFT, 64); m.put(EmulatorController.KEY_RIGHT, 128);
            m.put(EmulatorController.KEY_A, 256); m.put(EmulatorController.KEY_X, 512);
                m.put(EmulatorController.KEY_A_TURBO, 1256); m.put(EmulatorController.KEY_B_TURBO, 1001);
            return m;
        }
        @Override public String getName() { return "KeySNES • Snes9x"; }
        @Override public GfxProfile getDefaultGfxProfile() { return GFX.get(0); }
        @Override public SfxProfile getDefaultSfxProfile() { return SFX.get(2); }
        @Override public List<GfxProfile> getAvailableGfxProfiles() { return GFX; }
        @Override public List<SfxProfile> getAvailableSfxProfiles() { return SFX; }
        @Override public boolean supportsRawCheats() { return false; }
        @Override public int getNumQualityLevels() { return 3; }

        private static final class SnesGfxProfile extends GfxProfile {
            @Override public int toInt() {
                return fps == 50 ? 1 : 0;
            }
        }

        private static final class SnesSfxProfile extends SfxProfile {
            @Override public int toInt() {
                int x = rate / 11025;
                x += quality * 100;
                return x;
            }
        }
    }
}
