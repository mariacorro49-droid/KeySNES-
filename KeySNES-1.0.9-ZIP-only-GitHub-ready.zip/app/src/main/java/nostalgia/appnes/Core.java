package nostalgia.appnes;

import nostalgia.framework.base.JniBridge;

public final class Core extends JniBridge {
    private static final Core INSTANCE = new Core();
    static { System.loadLibrary("snes"); }
    private Core() {}
    public static Core getInstance() { return INSTANCE; }
}
