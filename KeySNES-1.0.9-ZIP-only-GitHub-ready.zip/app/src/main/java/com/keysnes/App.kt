package com.keysnes.emulator

import android.app.Application
import nostalgia.appnes.NesEmulator
import nostalgia.framework.base.EmulatorHolder

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        EmulatorHolder.setEmulatorClass(NesEmulator::class.java)
    }
}
