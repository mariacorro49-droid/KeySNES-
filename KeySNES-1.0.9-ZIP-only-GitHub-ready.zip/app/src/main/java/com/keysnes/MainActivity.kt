package com.keysnes.emulator

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.os.Bundle
import android.view.View
import android.widget.Toast
import java.io.File
import java.security.MessageDigest
import java.util.zip.ZipFile

class MainActivity : Activity() {
    companion object { private const val REQUEST_ROM = 1001 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        findViewById<View>(R.id.btnOpen).setOnClickListener {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
            }, REQUEST_ROM)
        }
    }

    @Deprecated("Deprecated on newer Android versions")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_ROM || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            // ROMs are kept in app-private persistent storage instead of cache.
            // This is important because Save States are persistent too and must
            // remain associated with the same ROM after the app is closed.
            val romFile = copyRomToPersistentStorage(uri)
            val playableFile = if (romFile.extension.equals("zip", ignoreCase = true)) {
                extractRomFromZip(romFile)
            } else {
                romFile
            }
            startActivity(Intent(this, MyEmulatorActivity::class.java)
                .putExtra(MyEmulatorActivity.EXTRA_ROM_PATH, playableFile.absolutePath))
        } catch (_: Exception) {
            Toast.makeText(this, "Não foi possível abrir a ROM", Toast.LENGTH_SHORT).show()
        }
    }

    private fun copyRomToPersistentStorage(uri: Uri): File {
        val romDir = File(filesDir, "roms")
        require(romDir.exists() || romDir.mkdirs()) { "Não foi possível criar a pasta das ROMs" }

        val ext = getRomExtension(uri)
        val tempFile = File.createTempFile("import_", ".tmp", romDir)
        val digest = MessageDigest.getInstance("MD5")

        try {
            contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "ROM indisponível" }
                tempFile.outputStream().use { output ->
                    val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                    while (true) {
                        val count = input.read(buffer)
                        if (count <= 0) break
                        digest.update(buffer, 0, count)
                        output.write(buffer, 0, count)
                    }
                }
            }

            val md5 = digest.digest().joinToString("") { "%02x".format(it) }
            val target = File(romDir, "$md5$ext")
            if (target.exists()) {
                tempFile.delete()
            } else {
                require(tempFile.renameTo(target)) { "Não foi possível guardar a ROM" }
            }
            return target
        } catch (e: Exception) {
            tempFile.delete()
            throw e
        }
    }


    /**
     * Snes9x also contains native ZIP support, but Android ROM import is kept
     * deliberately robust by extracting the first suitable SNES ROM from the
     * selected archive before starting the emulator. The original ZIP is never
     * deleted or modified.
     */
    private fun extractRomFromZip(zipFile: File): File {
        val romDir = zipFile.parentFile ?: filesDir
        val supported = setOf("sfc", "smc", "swc", "fig", "bs")

        ZipFile(zipFile).use { zip ->
            val entry = zip.entries().asSequence()
                .filter { !it.isDirectory }
                .filter { supported.contains(it.name.substringAfterLast('.', "").lowercase()) }
                .maxByOrNull { it.size }
                ?: throw IllegalArgumentException("O ZIP não contém uma ROM SNES compatível")

            val ext = "." + entry.name.substringAfterLast('.', "sfc").lowercase()
            val hash = MessageDigest.getInstance("MD5").digest(
                (zipFile.absolutePath + "\u0000" + entry.name + "\u0000" + entry.size).toByteArray(Charsets.UTF_8)
            ).joinToString("") { "%02x".format(it) }
            val output = File(romDir, "${hash}_rom$ext")

            if (!output.exists() || output.length() != entry.size) {
                zip.getInputStream(entry).use { input ->
                    output.outputStream().use { out ->
                        input.copyTo(out)
                    }
                }
            }
            return output
        }
    }

    private fun getRomExtension(uri: Uri): String {
        var name = uri.lastPathSegment?.substringAfterLast('/', "") ?: ""
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) name = cursor.getString(index) ?: name
            }
        }
        val lowerName = name.lowercase()
        val mime = contentResolver.getType(uri)?.lowercase().orEmpty()
        return when {
            lowerName.endsWith(".sfc") -> ".sfc"
            lowerName.endsWith(".smc") -> ".smc"
            lowerName.endsWith(".swc") -> ".swc"
            lowerName.endsWith(".fig") -> ".fig"
            lowerName.endsWith(".bs") -> ".bs"
            lowerName.endsWith(".zip") || mime == "application/zip" || mime == "application/x-zip-compressed" -> ".zip"
            else -> ".sfc"
        }
    }
}
