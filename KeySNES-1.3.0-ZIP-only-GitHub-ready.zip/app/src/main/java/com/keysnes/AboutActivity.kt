package com.keysnes.emulator

import android.app.Activity
import android.os.Bundle
import android.view.View

class AboutActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about_keysnes)
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
    }
}
