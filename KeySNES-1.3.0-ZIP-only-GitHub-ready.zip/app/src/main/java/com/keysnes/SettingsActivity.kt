package com.keysnes.emulator

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.CompoundButton
import android.widget.Switch

class SettingsActivity : Activity() {
    private val prefs by lazy { getSharedPreferences(PREFS_NAME, MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }

        bindSwitch(R.id.switchFullscreen, "fullscreen", false)
        bindSwitch(R.id.switchJardel, "jardel", false)
        bindSwitch(R.id.switchKeepScreenOn, "keep_screen_on", false)
        bindSwitch(R.id.switchConfirmExit, "confirm_exit", false)
    }

    private fun bindSwitch(id: Int, key: String, defaultValue: Boolean) {
        findViewById<Switch>(id).apply {
            isChecked = prefs.getBoolean(key, defaultValue)
            setOnCheckedChangeListener { _: CompoundButton, checked: Boolean ->
                prefs.edit().putBoolean(key, checked).apply()
            }
        }
    }

    companion object {
        const val PREFS_NAME = "keysnes_settings"
    }
}
