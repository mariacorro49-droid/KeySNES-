package com.keysnes.emulator

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Lightweight local library metadata. No background work and no emulator involvement. */
object GameLibrary {
    private const val PREFS = "keysnes_library"
    private const val KEY_RECENT = "recent"
    private const val KEY_FAVORITES = "favorites"

    data class Game(val id: String, val name: String, val path: String)

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun setRecent(context: Context, game: Game) {
        prefs(context).edit().putString(KEY_RECENT, JSONObject().apply {
            put("id", game.id)
            put("name", game.name)
            put("path", game.path)
        }.toString()).apply()
    }

    fun getRecent(context: Context): Game? {
        return try {
            val raw = prefs(context).getString(KEY_RECENT, null) ?: return null
            val o = JSONObject(raw)
            Game(o.getString("id"), o.getString("name"), o.getString("path"))
        } catch (_: Exception) { null }
    }

    fun isFavorite(context: Context, id: String): Boolean = getFavorites(context).any { it.id == id }

    fun toggleFavorite(context: Context, game: Game): Boolean {
        val current = getFavorites(context).toMutableList()
        val index = current.indexOfFirst { it.id == game.id }
        val added = index < 0
        if (added) current.add(game) else current.removeAt(index)
        saveFavorites(context, current)
        return added
    }

    fun getFavorites(context: Context): List<Game> {
        return try {
            val raw = prefs(context).getString(KEY_FAVORITES, null) ?: return emptyList()
            val array = JSONArray(raw)
            buildList(array.length()) {
                for (i in 0 until array.length()) {
                    val o = array.getJSONObject(i)
                    add(Game(o.getString("id"), o.getString("name"), o.getString("path")))
                }
            }
        } catch (_: Exception) { emptyList() }
    }

    private fun saveFavorites(context: Context, games: List<Game>) {
        val array = JSONArray()
        games.forEach { game ->
            array.put(JSONObject().apply {
                put("id", game.id)
                put("name", game.name)
                put("path", game.path)
            })
        }
        prefs(context).edit().putString(KEY_FAVORITES, array.toString()).apply()
    }
}
