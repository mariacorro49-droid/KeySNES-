package com.keysnes.emulator

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

class DiagnosticActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_diagnostic)

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<TextView>(R.id.valueAndroid).text = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
        findViewById<TextView>(R.id.valueArchitecture).text = Build.SUPPORTED_ABIS.firstOrNull() ?: "desconhecida"
        findViewById<TextView>(R.id.valueCpu).text = Build.HARDWARE.ifBlank { Build.MODEL }
        findViewById<TextView>(R.id.valueMemory).text = "${Runtime.getRuntime().maxMemory() / (1024 * 1024)} MB"
    }
}
