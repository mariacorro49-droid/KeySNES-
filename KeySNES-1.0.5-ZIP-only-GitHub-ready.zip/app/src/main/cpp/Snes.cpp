#include <jni.h>
#include <android/bitmap.h>
#include <GLES2/gl2.h>
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <mutex>
#include <string>
#include <vector>

#include "snes9x/libretro/libretro.h"

namespace {
std::mutex g_mutex;
bool g_started = false;
bool g_loaded = false;
std::string g_save_dir = ".";
std::string g_system_dir = ".";
uint32_t g_keys = 0;
std::vector<uint8_t> g_rgba;
unsigned g_width = 256, g_height = 224;
std::vector<int16_t> g_audio;

static const char *default_option(const char *key) {
    if (!key) return nullptr;
    struct Pair { const char *k; const char *v; };
    static const Pair p[] = {
        {"snes9x_region", "auto"}, {"snes9x_aspect", "4:3"},
        {"snes9x_overscan", "enabled"}, {"snes9x_gfx_hires", "disabled"},
        {"snes9x_hires_blend", "disabled"}, {"snes9x_blargg", "disabled"},
        {"snes9x_audio_interpolation", "gaussian"}, {"snes9x_up_down_allowed", "disabled"},
        {"snes9x_overclock_superfx", "100%"}, {"snes9x_overclock_cycles", "disabled"},
        {"snes9x_reduce_sprite_flicker", "disabled"}, {"snes9x_randomize_memory", "disabled"},
        {"snes9x_block_invalid_vram_access", "enabled"}, {"snes9x_echo_buffer_hack", "disabled"},
        {"snes9x_show_lightgun_settings", "enabled"}, {"snes9x_show_advanced_av_settings", "enabled"}
    };
    for (const auto &x : p) if (strcmp(x.k, key) == 0) return x.v;
    return nullptr;
}

bool environment_cb(unsigned cmd, void *data) {
    switch (cmd) {
        case RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY: {
            if (!data) return false; *(const char**)data = g_system_dir.c_str(); return true;
        }
        case RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY: {
            if (!data) return false; *(const char**)data = g_save_dir.c_str(); return true;
        }
        case RETRO_ENVIRONMENT_GET_CONTENT_DIRECTORY: {
            if (!data) return false; *(const char**)data = g_save_dir.c_str(); return true;
        }
        case RETRO_ENVIRONMENT_GET_VARIABLE: {
            auto *v = static_cast<retro_variable*>(data); if (!v) return false;
            v->value = default_option(v->key); return v->value != nullptr;
        }
        case RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE: {
            if (!data) return false; *(bool*)data = false; return true;
        }
        case RETRO_ENVIRONMENT_GET_AUDIO_VIDEO_ENABLE: {
            if (!data) return false; *(int*)data = 3; return true;
        }
        case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT: return true;
        case RETRO_ENVIRONMENT_SET_GEOMETRY: return true;
        case RETRO_ENVIRONMENT_SET_SYSTEM_AV_INFO: return true;
        case RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS: return true;
        case RETRO_ENVIRONMENT_SET_CONTROLLER_INFO: return true;
        case RETRO_ENVIRONMENT_SET_SUBSYSTEM_INFO: return true;
        case RETRO_ENVIRONMENT_SET_CORE_OPTIONS: return true;
        case RETRO_ENVIRONMENT_SET_CORE_OPTIONS_INTL: return true;
        case RETRO_ENVIRONMENT_SET_CORE_OPTIONS_DISPLAY: return true;
        case RETRO_ENVIRONMENT_SET_SUPPORT_ACHIEVEMENTS: return true;
        case RETRO_ENVIRONMENT_SET_PERFORMANCE_LEVEL: return true;
        case RETRO_ENVIRONMENT_SET_SERIALIZATION_QUIRKS: return true;
        default: return false;
    }
}

void video_cb(const void *data, unsigned width, unsigned height, size_t pitch) {
    if (!data || width == 0 || height == 0) return;
    g_width = std::min(width, 512u); g_height = std::min(height, 448u);
    g_rgba.resize((size_t)g_width * g_height * 4);
    const uint8_t *src = static_cast<const uint8_t*>(data);
    for (unsigned y = 0; y < g_height; ++y) {
        const uint16_t *row = reinterpret_cast<const uint16_t*>(src + y * pitch);
        uint8_t *dst = g_rgba.data() + (size_t)y * g_width * 4;
        for (unsigned x = 0; x < g_width; ++x) {
            uint16_t p = row[x];
            uint8_t r = (uint8_t)(((p >> 11) & 31) * 255 / 31);
            uint8_t g = (uint8_t)(((p >> 5) & 63) * 255 / 63);
            uint8_t b = (uint8_t)((p & 31) * 255 / 31);
            dst[x*4+0] = r; dst[x*4+1] = g; dst[x*4+2] = b; dst[x*4+3] = 255;
        }
    }
}

size_t audio_cb(const int16_t *data, size_t frames) {
    if (!data || !frames) return 0;
    const size_t samples = std::min(frames * 2, (size_t)65536);
    if (g_audio.size() + samples > 131072) {
        size_t drop = g_audio.size() + samples - 131072;
        g_audio.erase(g_audio.begin(), g_audio.begin() + std::min(drop, g_audio.size()));
    }
    g_audio.insert(g_audio.end(), data, data + samples);
    return frames;
}

void input_poll() {}
int16_t input_state(unsigned port, unsigned device, unsigned index, unsigned id) {
    if (device != RETRO_DEVICE_JOYPAD || port > 0 || index != 0 || id > RETRO_DEVICE_ID_JOYPAD_R) return 0;
    // Internal bit layout follows the framework's 8-bit-per-port convention:
    // B=0, Y=1, Select=2, Start=3, Up=4, Down=5, Left=6, Right=7,
    // A=8, X=9, L=10, R=11.
    static const uint32_t masks[] = {
        1u<<0, 1u<<4, 1u<<7, 1u<<6, 1u<<1, 1u<<8, 1u<<9, 1u<<10,
        1u<<11, 1u<<12, 1u<<13, 1u<<14
    };
    return (g_keys & masks[id]) ? 1 : 0;
}

void save_sram(const std::string &path) {
    if (!g_loaded) return;
    void *ptr = retro_get_memory_data(RETRO_MEMORY_SAVE_RAM);
    size_t size = retro_get_memory_size(RETRO_MEMORY_SAVE_RAM);
    if (!ptr || size == 0) return;
    std::ofstream out(path, std::ios::binary | std::ios::trunc);
    if (out) out.write(static_cast<const char*>(ptr), (std::streamsize)size);
}

void load_sram(const std::string &path) {
    if (!g_loaded) return;
    void *ptr = retro_get_memory_data(RETRO_MEMORY_SAVE_RAM);
    size_t size = retro_get_memory_size(RETRO_MEMORY_SAVE_RAM);
    if (!ptr || size == 0) return;
    std::ifstream in(path, std::ios::binary);
    if (!in) return;
    in.read(static_cast<char*>(ptr), (std::streamsize)size);
}

bool read_all(const char *path, std::vector<uint8_t> &out) {
    std::ifstream in(path, std::ios::binary | std::ios::ate);
    if (!in) return false;
    auto n = in.tellg(); if (n <= 0) return false;
    out.resize((size_t)n); in.seekg(0); in.read((char*)out.data(), n); return (bool)in;
}
}

extern "C" {
JNIEXPORT jboolean JNICALL Java_nostalgia_framework_base_JniBridge_setBaseDir(JNIEnv* env, jobject, jstring path) {
    const char *p = env->GetStringUTFChars(path, nullptr);
    std::lock_guard<std::mutex> lock(g_mutex);
    g_save_dir = p ? p : ".";
    g_system_dir = g_save_dir;
    env->ReleaseStringUTFChars(path, p);
    return JNI_TRUE;
}

JNIEXPORT jboolean JNICALL Java_nostalgia_framework_base_JniBridge_start(JNIEnv*, jobject, jint gfx, jint sfx, jint general) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_started) return JNI_TRUE;
    retro_set_environment(environment_cb);
    retro_set_video_refresh(video_cb);
    retro_set_audio_sample(nullptr);
    retro_set_audio_sample_batch(audio_cb);
    retro_set_input_poll(input_poll);
    retro_set_input_state(input_state);
    retro_init();
    retro_set_controller_port_device(0, RETRO_DEVICE_JOYPAD);
    g_audio.clear(); g_audio.reserve(131072); g_rgba.reserve(512u*448u*4u); g_started = true;
    return JNI_TRUE;
}

JNIEXPORT jboolean JNICALL Java_nostalgia_framework_base_JniBridge_loadGame(JNIEnv* env, jobject, jstring jpath, jstring jbatteryDir, jstring jbatteryFull) {
    const char *path = env->GetStringUTFChars(jpath, nullptr);
    const char *battery = env->GetStringUTFChars(jbatteryFull, nullptr);
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_loaded) { save_sram(std::string(battery)); retro_unload_game(); g_loaded = false; }
    retro_game_info info{}; info.path = path;
    bool ok = retro_load_game(&info);
    if (ok) { g_loaded = true; load_sram(std::string(battery)); }
    env->ReleaseStringUTFChars(jpath, path); env->ReleaseStringUTFChars(jbatteryFull, battery);
    return ok ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL Java_nostalgia_framework_base_JniBridge_emulate(JNIEnv*, jobject, jint keys, jint turbos, jint skip) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_loaded) return JNI_FALSE;
    g_keys = (uint32_t)keys;
    int frames = skip < 0 ? 10 : skip;
    for (int i = 0; i < frames; ++i) retro_run();
    retro_run();
    return JNI_TRUE;
}

JNIEXPORT jboolean JNICALL Java_nostalgia_framework_base_JniBridge_renderGL(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_rgba.empty()) return JNI_FALSE;
    glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, (GLsizei)g_width, (GLsizei)g_height, GL_RGBA, GL_UNSIGNED_BYTE, g_rgba.data());
    return JNI_TRUE;
}

JNIEXPORT jboolean JNICALL Java_nostalgia_framework_base_JniBridge_render(JNIEnv* env, jobject, jobject bitmap) {
    return Java_nostalgia_framework_base_JniBridge_renderVP(env, nullptr, bitmap, -1, -1);
}

JNIEXPORT jboolean JNICALL Java_nostalgia_framework_base_JniBridge_renderVP(JNIEnv* env, jobject, jobject bitmap, jint vw, jint vh) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_rgba.empty()) return JNI_FALSE;
    AndroidBitmapInfo bi{}; void *pixels = nullptr;
    if (AndroidBitmap_getInfo(env, bitmap, &bi) < 0 || AndroidBitmap_lockPixels(env, bitmap, &pixels) < 0) return JNI_FALSE;
    unsigned dw = vw > 0 ? (unsigned)vw : bi.width, dh = vh > 0 ? (unsigned)vh : bi.height;
    dw = std::min(dw, bi.width); dh = std::min(dh, bi.height);
    uint8_t *dst = (uint8_t*)pixels;
    for (unsigned y=0; y<dh; ++y) {
        unsigned sy = (unsigned)((uint64_t)y * g_height / dh);
        uint32_t *row = (uint32_t*)(dst + (size_t)y * bi.stride);
        for (unsigned x=0; x<dw; ++x) {
            unsigned sx = (unsigned)((uint64_t)x * g_width / dw);
            const uint8_t *s = g_rgba.data() + ((size_t)sy*g_width + sx)*4;
            row[x] = 0xff000000u | ((uint32_t)s[0]<<16) | ((uint32_t)s[1]<<8) | s[2];
        }
    }
    AndroidBitmap_unlockPixels(env, bitmap); return JNI_TRUE;
}

JNIEXPORT jboolean JNICALL Java_nostalgia_framework_base_JniBridge_renderHistory(JNIEnv*, jobject, jobject, jint, jint, jint) { return JNI_FALSE; }
JNIEXPORT jboolean JNICALL Java_nostalgia_framework_base_JniBridge_readPalette(JNIEnv*, jobject, jintArray) { return JNI_FALSE; }
JNIEXPORT jboolean JNICALL Java_nostalgia_framework_base_JniBridge_setViewPortSize(JNIEnv*, jobject, jint, jint) { return JNI_TRUE; }
JNIEXPORT jboolean JNICALL Java_nostalgia_framework_base_JniBridge_fireZapper(JNIEnv*, jobject, jint, jint) { return JNI_FALSE; }

JNIEXPORT jint JNICALL Java_nostalgia_framework_base_JniBridge_readSfxBuffer(JNIEnv* env, jobject, jshortArray arr) {
    std::lock_guard<std::mutex> lock(g_mutex);
    jsize cap = env->GetArrayLength(arr); size_t n = std::min((size_t)cap, g_audio.size());
    if (n) env->SetShortArrayRegion(arr, 0, (jsize)n, g_audio.data());
    g_audio.erase(g_audio.begin(), g_audio.begin()+n); return (jint)n;
}

JNIEXPORT jboolean JNICALL Java_nostalgia_framework_base_JniBridge_saveState(JNIEnv* env, jobject, jstring jpath, jint) {
    const char *path = env->GetStringUTFChars(jpath, nullptr);
    std::lock_guard<std::mutex> lock(g_mutex);
    size_t size = retro_serialize_size(); std::vector<uint8_t> data(size);
    bool ok = size && retro_serialize(data.data(), size);
    if (ok) { std::ofstream out(path, std::ios::binary|std::ios::trunc); ok = (bool)out && (bool)out.write((char*)data.data(), (std::streamsize)data.size()); }
    env->ReleaseStringUTFChars(jpath, path); return ok ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL Java_nostalgia_framework_base_JniBridge_loadState(JNIEnv* env, jobject, jstring jpath, jint) {
    const char *path = env->GetStringUTFChars(jpath, nullptr);
    std::lock_guard<std::mutex> lock(g_mutex); std::vector<uint8_t> data; bool ok = read_all(path, data);
    if (ok) ok = retro_unserialize(data.data(), data.size());
    env->ReleaseStringUTFChars(jpath, path); return ok ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL Java_nostalgia_framework_base_JniBridge_reset(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lock(g_mutex); if (!g_loaded) return JNI_FALSE; retro_reset(); return JNI_TRUE;
}

JNIEXPORT jboolean JNICALL Java_nostalgia_framework_base_JniBridge_stop(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_started) return JNI_TRUE;
    if (g_loaded) { retro_unload_game(); g_loaded = false; }
    retro_deinit(); g_started = false; g_audio.clear(); g_rgba.clear(); return JNI_TRUE;
}

JNIEXPORT jint JNICALL Java_nostalgia_framework_base_JniBridge_getHistoryItemCount(JNIEnv*, jobject) { return 0; }
JNIEXPORT jboolean JNICALL Java_nostalgia_framework_base_JniBridge_loadHistoryState(JNIEnv*, jobject, jint) { return JNI_FALSE; }

JNIEXPORT void JNICALL Java_nostalgia_framework_base_JniBridge_setExtraButton(JNIEnv*, jobject, jint button, jboolean pressed) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (button == 10 || button == 11) {
        uint32_t mask = 1u << button;
        if (pressed) g_keys |= mask; else g_keys &= ~mask;
    }
}
JNIEXPORT jboolean JNICALL Java_nostalgia_framework_base_JniBridge_enableCheat(JNIEnv* env, jobject, jstring jcode, jint) {
    const char *code = env->GetStringUTFChars(jcode, nullptr);
    retro_cheat_set(0, true, code); env->ReleaseStringUTFChars(jcode, code); return JNI_TRUE;
}
JNIEXPORT jboolean JNICALL Java_nostalgia_framework_base_JniBridge_enableRawCheat(JNIEnv*, jobject, jint, jint, jint) { return JNI_FALSE; }
}
