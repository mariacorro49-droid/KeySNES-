# KeySNES

KeySNES é um emulador de SNES para Android baseado no núcleo Snes9x e na organização visual do projeto KeyNES.

## Build no GitHub Actions

O workflow `.github/workflows/build-apk.yml`:

1. identifica a versão e o nome do APK;
2. prepara Java 17;
3. instala Android API 33, Build Tools 33.0.2, NDK 26.1.10909125 e CMake 3.22.1;
4. usa o projeto diretamente da raiz do repositório ou extrai um ZIP de projeto se `gradlew` não estiver na raiz;
5. valida a estrutura;
6. executa `./gradlew :app:assembleDebug`;
7. verifica e renomeia o APK;
8. publica o APK e um ZIP do projeto como artifacts.

APK esperado: `KeySNES-1.0.0-debug.apk`
