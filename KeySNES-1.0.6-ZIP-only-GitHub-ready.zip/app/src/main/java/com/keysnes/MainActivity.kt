package com.keysnes.emulator

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import java.io.File
import java.security.MessageDigest

class MainActivity : Activity() {
    companion object { private const val REQUEST_ROM = 1001 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        findViewById<View>(R.id.btnOpen).setOnClickListener {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
            }, REQUEST_ROM)
        }
    }

    @Deprecated("Deprecated on newer Android versions")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_ROM || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            // ROMs are kept in app-private persistent storage instead of cache.
            // This is important because Save States are persistent too and must
            // remain associated with the same ROM after the app is closed.
            val romFile = copyRomToPersistentStorage(uri)
            startActivity(Intent(this, MyEmulatorActivity::class.java)
                .putExtra(MyEmulatorActivity.EXTRA_ROM_PATH, romFile.absolutePath))
        } catch (_: Exception) {
            Toast.makeText(this, "Não foi possível abrir a ROM", Toast.LENGTH_SHORT).show()
        }
    }

    private fun copyRomToPersistentStorage(uri: Uri): File {
        val romDir = File(filesDir, "roms")
        require(romDir.exists() || romDir.mkdirs()) { "Não foi possível criar a pasta das ROMs" }

        val ext = getRomExtension(uri)
        val tempFile = File.createTempFile("import_", ".tmp", romDir)
        val digest = MessageDigest.getInstance("MD5")

        try {
            contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "ROM indisponível" }
                tempFile.outputStream().use { output ->
                    val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                    while (true) {
                        val count = input.read(buffer)
                        if (count <= 0) break
                        digest.update(buffer, 0, count)
                        output.write(buffer, 0, count)
                    }
                }
            }

            val md5 = digest.digest().joinToString("") { "%02x".format(it) }
            val target = File(romDir, "$md5$ext")
            if (target.exists()) {
                tempFile.delete()
            } else {
                require(tempFile.renameTo(target)) { "Não foi possível guardar a ROM" }
            }
            return target
        } catch (e: Exception) {
            tempFile.delete()
            throw e
        }
    }

    private fun getRomExtension(uri: Uri): String {
        val name = uri.lastPathSegment?.substringAfterLast('/', "") ?: ""
        val lowerName = name.lowercase()
        return when {
            lowerName.endsWith(".sfc") -> ".sfc"
            lowerName.endsWith(".smc") -> ".smc"
            lowerName.endsWith(".swc") -> ".swc"
            lowerName.endsWith(".fig") -> ".fig"
            lowerName.endsWith(".bs") -> ".bs"
            else -> ".sfc"
        }
    }
}
